DROP TABLE IF EXISTS "favorites";
