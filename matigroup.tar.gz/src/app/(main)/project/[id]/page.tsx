"use client";

import { api } from "~/trpc/react";
import { Card, CardContent, CardHeader, CardTitle } from "~/components/ui/card";
import { Badge } from "~/components/ui/badge";
import { Button } from "~/components/ui/button";
import { Progress } from "~/components/ui/progress";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Calendar, User, Download, Eye, FileText, Image as ImageIcon, FileVideo, FileAudio, Archive, File, Trash2, X, Pencil, Copy, ChevronLeft, ChevronRight } from "lucide-react";
import FavoriteButton from "~/components/favorite-button";
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "~/components/ui/dialog";
import EditProjectModal from "~/components/edit-project-modal";
import { toast } from "sonner";
import type { StoredAttachment, StoredImage } from "~/types/files";

interface ProjectPageProps {
  params: {
    id: string;
  };
}

export default function ProjectPage({ params }: ProjectPageProps) {
  const { data: user } = api.tg.getUser.useQuery();
  
  // Состояния для модального окна файла
  const [isFileModalOpen, setIsFileModalOpen] = useState(false);
  const [currentFile, setCurrentFile] = useState<{
    url?: string;
    text?: string;
    name: string;
    type: string;
    size?: number;
  } | null>(null);
  const [isEditOpen, setIsEditOpen] = useState(false);
  
  // Состояние для карусели изображений
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    return () => {
      if (currentFile?.url) {
        URL.revokeObjectURL(currentFile.url);
      }
    };
  }, [currentFile?.url]);

  useEffect(() => {
    if (!isFileModalOpen && currentFile?.url) {
      URL.revokeObjectURL(currentFile.url);
      setCurrentFile(null);
    }
  }, [isFileModalOpen, currentFile?.url]);
  
  // Используем оптимизированный запрос для быстрой загрузки
  const { data: project, isLoading } = api.projects.project.useQuery({
    id: parseInt(params.id),
  });
  
  // Загружаем полные данные только для админов и только при необходимости
  const { data: projectFull } = api.projects.projectFull.useQuery(
    { id: parseInt(params.id) },
    { 
      enabled: user?.role === "admin",
      refetchOnWindowFocus: false,
    }
  );
  
  const utils = api.useUtils();
  const deleteProject = api.projects.delete.useMutation({
    onSuccess: async () => {
      // Инвалидируем кэш для обновления списков
      await utils.projects.categories.invalidate();
      await utils.projects.featured.invalidate();
      await utils.projects.allProjects.invalidate();
      await utils.projects.favorites.invalidate();
    },
  });
  const router = useRouter();
  
  // Используем полные данные для админов, оптимизированные для остальных
  const displayProject = user?.role === "admin" ? (projectFull || project) : project;

  // Сброс индекса при изменении проекта
  useEffect(() => {
    setCurrentImageIndex(0);
  }, [displayProject?.id]);

  const handleDeleteProject = async () => {
    if (!displayProject) return;
    
    const confirmed = confirm(
      `Вы уверены, что хотите удалить проект "${displayProject.title}"? Это действие нельзя отменить.`
    );
    
    if (!confirmed) return;
    
    try {
      await deleteProject.mutateAsync({ id: displayProject.id });
      alert('Проект успешно удален!');
      router.push('/');
    } catch (error) {
      console.error('Ошибка удаления проекта:', error);
      alert('Ошибка при удалении проекта');
    }
  };

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    
    if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(extension || '')) {
      return <ImageIcon className="h-4 w-4" />;
    }
    if (['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm'].includes(extension || '')) {
      return <FileVideo className="h-4 w-4" />;
    }
    if (['mp3', 'wav', 'flac', 'aac', 'ogg'].includes(extension || '')) {
      return <FileAudio className="h-4 w-4" />;
    }
    if (['zip', 'rar', '7z', 'tar', 'gz'].includes(extension || '')) {
      return <Archive className="h-4 w-4" />;
    }
    if (['pdf'].includes(extension || '')) {
      return <FileText className="h-4 w-4" />;
    }
    
    return <File className="h-4 w-4" />;
  };

  const downloadBlob = (blob: Blob, fileName: string) => {
    try {
        const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
        link.href = url;
        link.download = fileName;
      link.style.display = "none";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (error) {
      console.error("Ошибка скачивания файла:", error);
      alert(
        "Ошибка при скачивании файла: " +
          (error instanceof Error ? error.message : String(error)),
      );
    }
  };

  const fetchAttachmentBlob = async (
    attachmentIndex: number,
    withWatermark: boolean,
  ) => {
    const initData = window.Telegram?.WebApp?.initData ?? "";
    const response = await fetch(
      `/api/files/${params.id}?attachmentIndex=${attachmentIndex}&watermark=${
        withWatermark ? "true" : "false"
      }`,
      {
        headers: {
          "x-telegram-init-data": initData,
        },
      },
    );
      
      if (!response.ok) {
        const errorText = await response.text();
      console.error("Ошибка сервера:", errorText);
        throw new Error(`Ошибка сервера: ${response.status} ${response.statusText}`);
      }
      
    return response.blob();
  };

  const downloadFileWithWatermark = async (
    attachmentIndex: number,
    fileName: string,
  ) => {
    try {
      const blob = await fetchAttachmentBlob(attachmentIndex, true);
      const finalName = fileName.replace(/\.[^/.]+$/, "_watermarked$&");
      downloadBlob(blob, finalName);
    } catch (error) {
      console.error("Ошибка скачивания файла с водяным знаком:", error);
      alert(
        "Ошибка при скачивании файла с водяным знаком: " +
          (error instanceof Error ? error.message : String(error)),
      );
    }
  };

  const openFile = async (attachment: StoredAttachment, index: number) => {
    try {
      const blob = await fetchAttachmentBlob(index, false);
      const fileType = attachment.mimeType || "application/octet-stream";
        const canDisplayInBrowser = 
        fileType.startsWith("image/") ||
        fileType === "application/pdf" ||
        fileType.startsWith("text/") ||
        fileType === "application/json";
        
        if (canDisplayInBrowser) {
        const url = URL.createObjectURL(blob);
        let text: string | undefined;
        if (fileType.startsWith("text/") || fileType === "application/json") {
          text = await blob.text();
        }
          setCurrentFile({
          url,
          text,
          name: attachment.originalName,
          type: fileType,
          size: attachment.size,
          });
          setIsFileModalOpen(true);
        return;
      }

      downloadBlob(blob, attachment.originalName);
    } catch (error) {
      console.error("Ошибка открытия файла:", error);
      alert(
        "Ошибка при открытии файла: " +
          (error instanceof Error ? error.message : String(error)),
      );
    }
  };

  const downloadFile = async (attachment: StoredAttachment, index: number) => {
    try {
      const blob = await fetchAttachmentBlob(index, false);
      downloadBlob(blob, attachment.originalName);
    } catch (error) {
      console.error("Ошибка скачивания файла:", error);
      alert(
        "Ошибка при скачивании файла: " +
          (error instanceof Error ? error.message : String(error)),
      );
    }
  };

  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!isLoading) return;
    
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          return 0;
        }
        return prev + 2;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [isLoading]);

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <div className="w-full max-w-md space-y-2 px-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Загрузка...</span>
            <span className="font-medium">{progress}%</span>
          </div>
          <Progress value={progress} className="w-full" />
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Назад
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Проект не найден</h1>
        </div>
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <span className="text-4xl mb-4">❌</span>
            <h3 className="text-lg font-semibold mb-2">Проект не найден</h3>
            <p className="text-muted-foreground text-center">
              Запрашиваемый проект не существует или был удален
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!displayProject) {
    return (
      <div className="space-y-6">
        <Link href="/" className="flex items-center gap-2 text-primary hover:underline">
          <ArrowLeft className="h-4 w-4" />
          Назад к категориям
        </Link>
        <h1 className="text-2xl font-bold">Проект не найден</h1>
        <p className="text-muted-foreground">
          Запрошенный проект не существует или был удален.
        </p>
      </div>
    );
  }

  // Функции для карусели
  const nextImage = () => {
    if (!displayProject?.images || displayProject.images.length === 0) return;
    setCurrentImageIndex((prev) => (prev + 1) % (displayProject.images?.length ?? 1));
  };

  const prevImage = () => {
    if (!displayProject?.images || displayProject.images.length === 0) return;
    setCurrentImageIndex((prev) => (prev - 1 + (displayProject.images?.length ?? 1)) % (displayProject.images?.length ?? 1));
  };

  return (
    <>
      <div className="flex flex-col md:flex-row gap-6 min-h-[calc(100vh-12rem)] pb-52">
        {/* Левая колонка - Изображения с каруселью (50%) */}
        <div className="w-full md:w-1/2 flex-shrink-0">
          {displayProject.images && displayProject.images.length > 0 ? (
            <div className="relative w-full h-full min-h-[400px] bg-muted rounded-lg overflow-hidden">
              {/* Основное изображение */}
              <img
                src={(displayProject.images[currentImageIndex] as StoredImage).url}
                alt={`${displayProject.title} - изображение ${currentImageIndex + 1}`}
                className="w-full h-full object-cover"
                loading="lazy"
                decoding="async"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjNmNGY2Ii8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzY2NjY2NiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkltYWdlPC90ZXh0Pjwvc3ZnPg==';
                }}
              />
              
              {/* Кнопки навигации (если изображений больше одного) */}
              {displayProject.images.length > 1 && (
                <>
                  <Button
                    variant="outline"
                    size="icon"
                    className="absolute left-4 top-1/2 -translate-y-1/2 bg-background/80 hover:bg-background"
                    onClick={prevImage}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="absolute right-4 top-1/2 -translate-y-1/2 bg-background/80 hover:bg-background"
                    onClick={nextImage}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  
                  {/* Индикаторы */}
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                    {displayProject.images.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentImageIndex(index)}
                        className={`h-2 rounded-full transition-all ${
                          index === currentImageIndex 
                            ? 'w-8 bg-primary' 
                            : 'w-2 bg-background/50 hover:bg-background/70'
                        }`}
                        aria-label={`Перейти к изображению ${index + 1}`}
                      />
                    ))}
                  </div>
                  
                  {/* Счетчик изображений */}
                  <div className="absolute top-4 right-4 bg-background/80 px-3 py-1 rounded-full text-sm">
                    {currentImageIndex + 1} / {displayProject.images.length}
                  </div>
                </>
              )}
            </div>
          ) : (
            <div className="w-full h-full min-h-[400px] bg-muted rounded-lg flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <ImageIcon className="h-16 w-16 mx-auto mb-2 opacity-50" />
                <p>Нет изображений</p>
              </div>
            </div>
          )}
        </div>

        {/* Правая колонка - Информация и кнопки (50%) */}
        <div className="w-full md:w-1/2 flex flex-col space-y-6">
          {/* Заголовок и кнопки */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <h1 className="text-2xl font-bold">{displayProject.title}</h1>
              {displayProject.featured && (
                <div className="mt-1">
                  <Badge variant="default">⭐ Рекомендуемый</Badge>
                </div>
              )}
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <FavoriteButton projectId={displayProject.id} />
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  try {
                    const link = `https://t.me/matibott_bot?startapp=project_${displayProject.id}`;
                    void navigator.clipboard.writeText(link);
                    toast.success("Ссылка для Mini App скопирована");
                  } catch (e) {
                    toast.error("Не удалось скопировать ссылку");
                  }
                }}
                title="Скопировать ссылку"
              >
                <Copy className="h-4 w-4 mr-2" />
                Скопировать
              </Button>
            </div>
          </div>

          {/* Описание */}
          <Card className="flex-1 flex flex-col">
            <CardHeader>
              <CardTitle>Описание проекта</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 flex-1">
              {displayProject.description && (
                <p className="text-muted-foreground">{displayProject.description}</p>
              )}
              
              {displayProject.content && (
                <div className="prose max-w-none">
                  <div dangerouslySetInnerHTML={{ __html: displayProject.content }} />
                </div>
              )}

            {displayProject.attachments && displayProject.attachments.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Вложения</h3>
                <div className="space-y-2">
                  {displayProject.attachments.map((attachment: StoredAttachment, index: number) => {
                    const fileName = attachment.originalName || `attachment_${index + 1}`;
                    const fileIcon = getFileIcon(fileName);
                    const mimeType = attachment.mimeType || "";
                    
                         return (
                           <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                             <div className="flex items-center gap-3 flex-1 min-w-0">
                               {fileIcon}
                               <div className="flex-1 min-w-0">
                                 <span className="font-medium block truncate" title={fileName}>{fileName}</span>
                                 <div className="text-xs text-muted-foreground truncate">
                                   {mimeType && `Тип: ${mimeType}`}
                              {attachment.size > 0 && ` • Размер: ${Math.round(attachment.size / 1024)} KB`}
                              {attachment.size === 0 && ` • ⚠️ Файл пустой`}
                                 </div>
                               </div>
                             </div>
                             <div className="flex gap-2">
                               <Button
                                 variant="outline"
                                 size="sm"
                            onClick={() => openFile(attachment, index)}
                            disabled={attachment.size === 0}
                                 title="Открыть файл (для презентаций и архивов - скачать)"
                               >
                                 <Eye className="h-4 w-4 mr-1" />
                                 Открыть
                               </Button>
                               <Button
                                 variant="outline"
                                 size="sm"
                            onClick={() => downloadFile(attachment, index)}
                            disabled={attachment.size === 0}
                               >
                                 <Download className="h-4 w-4 mr-1" />
                                 Скачать
                               </Button>
                               <Button
                                 variant="outline"
                                 size="sm"
                                onClick={() => {
                                  void downloadFileWithWatermark(index, fileName);
                                 }}
                            disabled={attachment.size === 0}
                                 className="bg-gray-50 hover:bg-gray-100"
                                 title="Скачать файл с водяным знаком '123' (очень прозрачный, почти незаметный)"
                               >
                                 <Download className="h-4 w-4 mr-1" />
                                 С водяным знаком
                               </Button>
                             </div>
                           </div>
                         );
                  })}
                </div>
              </div>
            )}

            {/* Кнопки управления (внизу под описанием) */}
            {user?.role === "admin" && (
              <div className="flex flex-wrap gap-2 pt-4 border-t">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsEditOpen(true)}
                  title="Редактировать проект"
                >
                  <Pencil className="h-4 w-4 mr-2" />
                  Редактировать
                </Button>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={handleDeleteProject}
                  disabled={deleteProject.isPending}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  {deleteProject.isPending ? "Удаление..." : "Удалить"}
                </Button>
                <div className="ml-auto flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span>{new Date(displayProject.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
        </div>
      </div>
      {/* Модальное окно для просмотра файла */}
      <Dialog open={isFileModalOpen} onOpenChange={setIsFileModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsFileModalOpen(false)}
                  className="p-2"
                >
                  <ArrowLeft className="h-4 w-4" />
                </Button>
                <span>{currentFile?.name || 'Просмотр файла'}</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsFileModalOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </DialogTitle>
          </DialogHeader>
          
          <div className="flex-1 overflow-auto">
            {currentFile && (
              <div className="space-y-4">
                {/* Информация о файле */}
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>Тип: {currentFile.type}</span>
                  <span>•</span>
                  <span>
                    Размер:{" "}
                    {currentFile.size ? `${Math.round(currentFile.size / 1024)} KB` : "—"}
                  </span>
                </div>
                
                {/* Отображение файла в зависимости от типа */}
                {currentFile.type.startsWith('image/') ? (
                  <div className="flex justify-center">
                    <img
                      src={currentFile.url}
                      alt={currentFile.name}
                      className="max-w-full max-h-[60vh] object-contain rounded-lg"
                    />
                  </div>
                ) : currentFile.type === 'application/pdf' ? (
                  <div className="w-full h-[60vh]">
                    <iframe
                      src={currentFile.url}
                      className="w-full h-full border rounded-lg"
                      title={currentFile.name}
                    />
                  </div>
                ) : currentFile.type.startsWith('text/') ? (
                  <div className="bg-muted p-4 rounded-lg">
                    <pre className="whitespace-pre-wrap text-sm overflow-auto max-h-[60vh]">
                      {currentFile.text}
                    </pre>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 space-y-4">
                    <File className="h-16 w-16 text-muted-foreground" />
                    <div className="text-center">
                      <p className="text-lg font-medium">Файл не может быть предварительно просмотрен</p>
                      <p className="text-muted-foreground">
                        Используйте кнопку &quot;Скачать&quot; для загрузки файла
                      </p>
                    </div>
                    <Button
                      onClick={() => {
                        if (currentFile?.url) {
                          window.open(currentFile.url, "_blank");
                        }
                      }}
                      className="mt-4"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Скачать файл
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      
      {user?.role === "admin" && (
        <EditProjectModal
          isOpen={isEditOpen}
          onClose={() => setIsEditOpen(false)}
          project={{
            id: displayProject.id,
            title: displayProject.title,
            description: displayProject.description,
            content: displayProject.content,
            categoryId: displayProject.categoryId,
            images: displayProject.images ?? [],
            attachments: displayProject.attachments ?? [],
            featured: displayProject.featured,
            status: displayProject.status,
          }}
        />
      )}
    </>
  );
}
